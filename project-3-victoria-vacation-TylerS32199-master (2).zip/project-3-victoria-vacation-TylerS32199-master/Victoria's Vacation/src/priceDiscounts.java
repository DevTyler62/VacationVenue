
public class priceDiscounts extends pricing {
double numOfChairs;
double daysRentingBoat;

public double calculateNumOfChairs() {
	return numOfChairs;
}
public double calculateNumOfDaysRentingBoat() {
	return daysRentingBoat;
}
}
